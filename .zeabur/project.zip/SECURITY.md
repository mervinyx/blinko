# Security Policy

## Reporting a bug

Report security bugs via GitHub [issues](https://github.com/blinko-space/blinko/issues).

For more information, please contact [blinkospace@gmail.com](blinkospace@gmail.com).
