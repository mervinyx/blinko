export const DBBAK_TASK_NAME = 'Backup Database'
export const ARCHIVE_BLINKO_TASK_NAME = 'Auto Archive Blinko'
export const RECOMMAND_TASK_NAME = 'Follow Recommand Index'
export const VECTOR_DB_FILE_PATH = 'file:.blinko/vector/embeddings.db'