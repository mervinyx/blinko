-- AlterTable
ALTER TABLE "notes" ADD COLUMN     "isReviewed" BOOLEAN NOT NULL DEFAULT false;
