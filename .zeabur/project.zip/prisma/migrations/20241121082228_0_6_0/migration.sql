-- AlterTable
ALTER TABLE "attachments" ADD COLUMN     "type" VARCHAR NOT NULL DEFAULT '';
