-- AlterTable
ALTER TABLE "accounts" ADD COLUMN     "linkAccountId" INTEGER;
