-- AlterTable
ALTER TABLE "accounts" ADD COLUMN     "loginType" VARCHAR NOT NULL DEFAULT '';
