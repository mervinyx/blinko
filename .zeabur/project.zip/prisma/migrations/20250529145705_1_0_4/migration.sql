-- AlterTable
ALTER TABLE "conversation" ADD COLUMN     "isShare" BOOLEAN NOT NULL DEFAULT false;
