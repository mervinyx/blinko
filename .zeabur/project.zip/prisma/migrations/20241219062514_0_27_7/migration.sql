-- AlterTable
ALTER TABLE "attachments" ADD COLUMN     "depth" INTEGER,
ADD COLUMN     "perfixPath" VARCHAR DEFAULT '';
