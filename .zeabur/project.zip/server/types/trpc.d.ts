import { AppRouter } from '../routerTrpc/_app';
export const appRouter: typeof AppRouter;