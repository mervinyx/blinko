import EventEmitter from "events";

export const eventBus = new EventEmitter();