export declare function setStatusBarColor(hexColor: string): Promise<null>;
export declare function openAppSettings(): Promise<void>;
